local events = {
    handlers = {}
}

local __parse_path = parse_path
local __pack_is_installed = pack.is_installed

function events.on(event, func)
    local prefix = __parse_path(event)
    if prefix ~= "core" and not __pack_is_installed(prefix) then
        error("pack prefix required")
    end
    if events.handlers[event] == nil then
        events.handlers[event] = {}
    end
    table.insert(events.handlers[event], func)
    return func
end

function events.reset(event, func)
    if func == nil then
        events.handlers[event] = nil
    else
        events.handlers[event] = {func}
    end
end

function events.remove(event, handler)
    local handlers = events.handlers[event]
    if not handlers then
        return
    end
    table.remove_value(handlers, handler)
end

function events.remove_by_prefix(prefix)
    for name, handlers in pairs(events.handlers) do
        local actualname = name
        if type(name) == 'table' then
            actualname = name[1]
        end
        if actualname:sub(1, #prefix+1) == prefix..':' then
            events.handlers[actualname] = nil
        end
    end
end

function events.emit(event, ...)
    local result = nil
    local handlers = events.handlers[event]
    if handlers == nil then
        return nil
    end
    for _, func in ipairs(handlers) do
        local status, newres = xpcall(func, __vc__error, ...)
        if not status then
            debug.error("error in event ("..event..") handler"..(newres and (": "..tostring(newres)) or ""))
        else
            result = result or newres
        end
    end
    return result
end
return events
